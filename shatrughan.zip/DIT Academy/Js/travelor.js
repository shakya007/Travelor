
$('.book-main').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});

// Aos Animation
  AOS.init();


// hamburgers

$(document).ready(function () {
  $('.ham-burger').click(function () {
    $('body').toggleClass('show-mobile-menu')
  })
});

// back to top animation

$("#back-top").click(function () {
  $("html, body").animate({scrollTop: 0}, 1000);

});

$(window).scroll(function() {
  if ($(this).scrollTop()) {
      $('#back-top').fadeIn();
  } else {
      $('#back-top').fadeOut(1500);
  }
});

